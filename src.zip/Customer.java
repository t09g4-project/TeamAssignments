import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

class Customer {
	private String name;
	private int customerID;

	public Customer(BufferedReader reader) throws IOException {
		String line = reader.readLine();
		if (line == null) {
			name = "";
			return;
		}
		if (line.contains("null")) {
			throw new IOException("Customer is null in file");
		}
		name = line;
		line = reader.readLine();
		if (line == null) {
			throw new IOException("No customer ID found in file");
		}
		customerID = Integer.parseInt(line);
	}

	public Customer(String a, int b) {
		setName(a);
		setCustomerID(b);
	}

	public Customer(String c) {
		this.name = c;
	}

	public Customer(Customer c) {
		setName(c.getName());
		setCustomerID(c.getID());
	}

	public Customer() {

	}

	public String getName() {
		return this.name;
	}

	public int getID() {
		return this.customerID;
	}

	public String toString() {
		return this.name + " " + this.customerID;
	}

	public void setName(String c) {
		this.name = c;
	}

	public void setCustomerID(int b) {
		this.customerID = b;
	}

	public void save(PrintWriter out) throws IOException {
		out.println(getName());
		out.println(getID());
	}

}