import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

public class SavingsAccount extends BankAccount {
	private double annualInterestRate = 0.05;
	private double minimumBalance;

	public SavingsAccount() {

	}

	public SavingsAccount(double a, double b) {
		super(a);
		this.annualInterestRate = b;
	}

	public SavingsAccount(double a) {
		this.annualInterestRate = a;
	}

	public SavingsAccount(Customer acc, double bala) {
		super(acc, bala);
		setAccountHolder(acc);
		setBalance(bala);
	}

	public SavingsAccount(Customer acc, double bala, double annu) {
		super(acc, bala);
		this.annualInterestRate = annu;
	}

	public SavingsAccount(SavingsAccount c) {
		super(c.getAccountHolder(), c.getBalance());

		this.annualInterestRate = c.annualInterestRate;
		this.minimumBalance = c.minimumBalance;
	}

	public SavingsAccount(BufferedReader reader) throws IOException {
		super(reader);
		annualInterestRate = Double.parseDouble(reader.readLine());
		minimumBalance = Double.parseDouble(reader.readLine());
	}

	public void saveToTextFile(String filename) throws IOException {
		super.saveToTextFile(filename);
		PrintWriter out = new PrintWriter(new FileOutputStream(filename, true));
		out.println(annualInterestRate);
		out.println(minimumBalance);
		out.close();
	}

	public double getAnnualInterestRate() {
		return this.annualInterestRate;
	}

	public double getMinimumBalance() {
		return this.minimumBalance;
	}

	public void setAnnualInterestRate(double b) {
		if ((b >= 0) && (b <= 1))
			annualInterestRate = b;

	}

	public double withdraw(double b) {
		if ((getBalance() - b) >= minimumBalance) {

			setBalance(getBalance() - b);
		}
		return getBalance();
	}

	public void setMinimumBalance(double b) {
		this.minimumBalance = b;
	}

	public double getMonthlyFeesAndInterest() {
		return (getBalance() * annualInterestRate / 12);
	}
}