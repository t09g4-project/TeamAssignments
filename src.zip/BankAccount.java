import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

public abstract class BankAccount {
	private double balance = 0.0;
	private String accountNumber = "1234";
	private Customer accountHolder;

	public BankAccount(BufferedReader reader) throws IOException {
		String line = reader.readLine();
		balance = Double.parseDouble(line);
		accountNumber = reader.readLine();
		try {
			accountHolder = new Customer(reader);
		} catch (IOException e) {

		}
	}

	public void saveToTextFile(String filename) throws IOException {
		PrintWriter out = new PrintWriter(filename);
		out.println(balance);
		out.println(accountNumber);
		if (accountHolder == null) {
			out.println(accountHolder);
		} else {
			accountHolder.save(out);
		}
		out.close();
	}

	//
	public Customer getAccountHolder() {
		if (accountHolder != null) {
			return accountHolder;
		} else {
			return null;
		}
	}

	public void setAccountHolder(Customer c) {
		/*
		 * if (accountHolder!=null) { accountHolder.name=c.name;
		 * accountHolder.customerID=c.customerID; }
		 */
		this.accountHolder = c;

	}

	public void setBalance(double b) {
		balance = b;
	}

	public void setAccountNumber(String s) {
		accountNumber = s;
	}

	protected abstract double getMonthlyFeesAndInterest();

	public void monthEndUpdate() {
		double newValue = getMonthlyFeesAndInterest();
		balance += newValue;
	}

	public double getBalance() {
		return balance;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public String toString() {

		// accountHolder=new Customer();
		return "(" + accountHolder.getName() + " " + accountHolder.getID()
				+ ") " + accountNumber + ": " + balance;

	}

	public double deposit(double a) {
		if (a > 0) {
			balance += a;
		}
		return 0;
	}

	public double withdraw(double b) {
		if (b > 0 && b <= balance)
			balance -= b;
		return 0;
	}

	public BankAccount() {

	}

	public BankAccount(double a) {

		balance = a;
	}

	public BankAccount(double b, String c) {
		balance = b;

		accountNumber = c;
	}

	public BankAccount(Customer e, double f) {
		accountHolder = e;
		balance = f;

	}

	public BankAccount(Customer z, String s) {
		this.accountHolder = z;
		this.accountHolder.setName(s);
	}

	public BankAccount(Customer k, int g) {
		this.accountHolder = k;
		this.accountHolder.setCustomerID(g);
	}

	public BankAccount(Customer k, String n, double b) {
		if (accountHolder != null) {
			this.accountHolder = k;
			this.accountHolder.setName(n);
			this.balance = b;
		}
	}

	public BankAccount(BankAccount b)

	{
		this.balance = b.balance;
		this.accountNumber = b.accountNumber;
		this.accountHolder = b.accountHolder;

		/*
		 * if (b.accountHolder.name!=null) { accountHolder=new Customer();
		 * this.accountHolder.name=b.accountHolder.name;
		 * //this.accountHolder.customerID=b.accountHolder.customerID; } if
		 * (b.accountHolder.customerID!=0) {
		 * //this.accountHolder.name=b.accountHolder.name;
		 * this.accountHolder.customerID=b.accountHolder.customerID; }
		 */
	}

	public void transfer(int x, BankAccount b) {

		if (b.balance < this.balance)

		{
			if (x <= this.balance) {
				this.balance -= x;
				b.balance += x;
			}
		} else {
			if (x <= b.balance) {
				b.balance -= x;
				this.balance += x;
			}
		}
	}
	/*
	 * Customer nameInBank= new Customer(); Customer idInBank=new Customer();
	 * public String getName() { return nameInBank.name; } public int
	 * getCustomerID() { return idInBank.customerID; }
	 */

}
